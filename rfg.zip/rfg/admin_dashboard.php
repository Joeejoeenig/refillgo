<?php
// admin_dashboard.php
require 'config.php';

// Lindungi halaman, hanya untuk admin yang sudah login
if (!isset($_SESSION['admin_id'])) {
    header("location: login.php");
    exit;
}

$admin_id = $_SESSION['admin_id'];
$message = '';
$current_tab = $_GET['tab'] ?? 'pesanan'; // Default tab adalah pesanan

// === LOGIKA UNTUK PROSES FORM ===

// 1. Proses Tambah/Update Galon
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_galon'])) {
    $tipe_galon = $_POST['tipe_galon'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = $conn->prepare("INSERT INTO galon (Tipe_Galon, Harga, Stok, AdminID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdii", $tipe_galon, $harga, $stok, $admin_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "<p class='success'>Galon baru berhasil ditambahkan.</p>";
        header("Location: admin_dashboard.php?tab=galon"); // Redirect ke halaman yang sama
        exit();
    } else {
        $message = "<p class='error'>Gagal menambahkan galon: " . $conn->error . "</p>";
    }
    $stmt->close();
}

// 2. Proses Update Status Pesanan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $pesanan_id = $_POST['pesanan_id'];
    $status_baru = $_POST['status_pesanan'];

    $stmt = $conn->prepare("UPDATE pesanan SET Status_Pesanan = ? WHERE PesananID = ?");
    $stmt->bind_param("si", $status_baru, $pesanan_id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "<p class='success'>Status pesanan #$pesanan_id berhasil diperbarui.</p>";
        header("Location: admin_dashboard.php"); // Redirect ke halaman yang sama
        exit();
    } else {
        $message = "<p class='error'>Gagal memperbarui status.</p>";
    }
    $stmt->close();
}

// 3. Proses Tambah Kurir
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_kurir'])) {
    $nama_kurir = $_POST['nama_kurir'];
    $no_telepon = $_POST['no_telepon'];

    $stmt = $conn->prepare("INSERT INTO kurir (NamaKurir, No_Telepon) VALUES (?, ?)");
    $stmt->bind_param("ss", $nama_kurir, $no_telepon);

    if ($stmt->execute()) {
        $_SESSION['message'] = "<p class='success'>Kurir baru berhasil ditambahkan.</p>";
        header("Location: admin_dashboard.php?tab=kurir");
        exit();
    } else {
        $message = "<p class='error'>Gagal menambahkan kurir: " . $conn->error . "</p>";
    }
    $stmt->close();
}


// === LOGIKA UNTUK MENGAMBIL DATA ===
$pesanan_list = $conn->query("
    SELECT p.PesananID, p.Tanggal_Pesan, u.Nama, g.Tipe_Galon, p.Jumlah_Galon, p.Status_Pesanan
    FROM pesanan p
    JOIN pengguna u ON p.UserID = u.UserID
    JOIN galon g ON p.GalonID = g.GalonID
    ORDER BY p.Tanggal_Pesan DESC
");
$galon_list = $conn->query("SELECT * FROM galon ORDER BY Tipe_Galon");
$kurir_list = $conn->query("SELECT * FROM kurir ORDER BY NamaKurir");
$pengguna_list = $conn->query("SELECT UserID, Nama, Email, Nomor_Telepon, Alamat FROM pengguna ORDER BY Nama");

// Di bagian atas file, sebelum HTML:
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Hapus pesan setelah ditampilkan
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Water Delivery</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="css/admin_styles.css" rel="stylesheet">
</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo-container">
                    <img src="img/refillgologo.webp" alt="Logo" class="logo">
                    <h2>AquaAdmin</h2>
                </div>
            </div>

            <nav class="sidebar-nav">
                <ul>
                    <li class="nav-item active" data-section="pesanan">
                        <a href="#pesanan">
                            <i class="fas fa-shopping-cart"></i>
                            <span>Manajemen Pesanan</span>
                        </a>
                    </li>
                    <li class="nav-item" data-section="galon">
                        <a href="#galon">
                            <i class="fas fa-tint"></i>
                            <span>Manajemen Galon</span>
                        </a>
                    </li>
                    <li class="nav-item" data-section="kurir">
                        <a href="#kurir">
                            <i class="fas fa-truck"></i>
                            <span>Manajemen Kurir</span>
                        </a>
                    </li>
                    <li class="nav-item" data-section="pengguna">
                        <a href="#pengguna">
                            <i class="fas fa-users"></i>
                            <span>Data Pengguna</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <div class="admin-profile">
                    <img src="img/pp.jpg" alt="Admin" class="admin-avatar">
                    <div class="admin-info">
                        <span class="admin-name">Admin</span>
                        <span class="admin-role">Administrator</span>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="main-header">
                <div class="header-left">
                    <button class="sidebar-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="page-title">Dashboard</h1>
                </div>
                <div class="header-right">
                    <div class="header-actions">
                        <button class="notification-btn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge">3</span>
                        </button>
                        <div class="user-menu">
                            <img src="img/pp.jpg" alt="User" class="user-avatar">
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content Sections -->
            <div class="content-wrapper">
                <?php if (isset($message)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- Dashboard Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $pesanan_list->num_rows; ?></h3>
                            <p>Total Pesanan</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-tint"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $galon_list->num_rows; ?></h3>
                            <p>Jenis Galon</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-truck"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $kurir_list->num_rows; ?></h3>
                            <p>Kurir Aktif</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo $pengguna_list->num_rows; ?></h3>
                            <p>Pengguna</p>
                        </div>
                    </div>
                </div>

                <!-- Pesanan Section -->
                <section id="pesanan" class="content-section active">
                    <div class="section-header">
                        <h2><i class="fas fa-shopping-cart"></i> Manajemen Pesanan</h2>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Daftar Semua Pesanan</h3>
                            <div class="card-actions">
                                <button class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Tambah Pesanan
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Tanggal</th>
                                            <th>Pelanggan</th>
                                            <th>Galon</th>
                                            <th>Jumlah</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $pesanan_list->fetch_assoc()): ?>
                                            <tr>
                                                <td>#<?php echo $row['PesananID']; ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($row['Tanggal_Pesan'])); ?></td>
                                                <td><?php echo htmlspecialchars($row['Nama']); ?></td>
                                                <td><?php echo htmlspecialchars($row['Tipe_Galon']); ?></td>
                                                <td><?php echo $row['Jumlah_Galon']; ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo strtolower($row['Status_Pesanan']); ?>">
                                                        <?php echo $row['Status_Pesanan']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <form method="POST" class="status-form">
                                                        <input type="hidden" name="pesanan_id" value="<?php echo $row['PesananID']; ?>">
                                                        <select name="status_pesanan" class="status-select">
                                                            <option value="Menunggu" <?php echo $row['Status_Pesanan'] == 'Menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                                                            <option value="Diproses" <?php echo $row['Status_Pesanan'] == 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                                                            <option value="Dikirim" <?php echo $row['Status_Pesanan'] == 'Dikirim' ? 'selected' : ''; ?>>Dikirim</option>
                                                            <option value="Selesai" <?php echo $row['Status_Pesanan'] == 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                                                            <option value="Dibatalkan" <?php echo $row['Status_Pesanan'] == 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                                                        </select>
                                                        <button type="submit" name="update_status" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-save"></i> Simpan
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Galon Section -->
                <section id="galon" class="content-section">
                    <div class="section-header">
                        <h2><i class="fas fa-tint"></i> Manajemen Galon</h2>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Tambah Galon Baru</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" class="form-grid">
                                <div class="form-group">
                                    <label for="tipe_galon">
                                        <i class="fas fa-tint"></i> Tipe Galon
                                    </label>
                                    <input type="text" id="tipe_galon" name="tipe_galon" required class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="harga">
                                        <i class="fas fa-money-bill"></i> Harga
                                    </label>
                                    <input type="number" id="harga" name="harga" step="0.01" required class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="stok">
                                        <i class="fas fa-boxes"></i> Stok
                                    </label>
                                    <input type="number" id="stok" name="stok" required class="form-control">
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="add_galon" class="btn btn-primary">
                                        <i class="fas fa-plus"></i> Tambah Galon
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Daftar Galon</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Tipe</th>
                                            <th>Harga</th>
                                            <th>Stok</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $galon_list->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $row['GalonID']; ?></td>
                                                <td><?php echo htmlspecialchars($row['Tipe_Galon']); ?></td>
                                                <td>Rp <?php echo number_format($row['Harga'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <span class="stock-badge <?php echo $row['Stok'] > 10 ? 'stock-good' : ($row['Stok'] > 0 ? 'stock-low' : 'stock-empty'); ?>">
                                                        <?php echo $row['Stok']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-secondary">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Kurir Section -->
                <section id="kurir" class="content-section">
                    <div class="section-header">
                        <h2><i class="fas fa-truck"></i> Manajemen Kurir</h2>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Tambah Kurir Baru</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" class="form-grid">
                                <div class="form-group">
                                    <label for="nama_kurir">
                                        <i class="fas fa-user"></i> Nama Kurir
                                    </label>
                                    <input type="text" id="nama_kurir" name="nama_kurir" required class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="no_telepon">
                                        <i class="fas fa-phone"></i> No. Telepon
                                    </label>
                                    <input type="tel" id="no_telepon" name="no_telepon" required class="form-control">
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="add_kurir" class="btn btn-primary">
                                        <i class="fas fa-plus"></i> Tambah Kurir
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Daftar Kurir</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama Kurir</th>
                                            <th>No. Telepon</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $kurir_list->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $row['KurirID']; ?></td>
                                                <td><?php echo htmlspecialchars($row['NamaKurir']); ?></td>
                                                <td><?php echo htmlspecialchars($row['No_Telepon']); ?></td>
                                                <td>
                                                    <span class="status-badge status-aktif">Aktif</span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-secondary">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Pengguna Section -->
                <section id="pengguna" class="content-section">
                    <div class="section-header">
                        <h2><i class="fas fa-users"></i> Data Pengguna</h2>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3>Daftar Pengguna Terdaftar</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>Telepon</th>
                                            <th>Alamat</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $pengguna_list->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $row['UserID']; ?></td>
                                                <td><?php echo htmlspecialchars($row['Nama']); ?></td>
                                                <td><?php echo htmlspecialchars($row['Email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['Nomor_Telepon']); ?></td>
                                                <td><?php echo htmlspecialchars($row['Alamat']); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-secondary">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <script src="js/admin_script.js"></script>
</body>

</html>