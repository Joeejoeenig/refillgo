<?php // index.php
// Halaman utama yang mengarahkan pengguna
require 'config.php';

if (isset($_SESSION['admin_id'])) {
    header("location: admin_dashboard.php");
    exit;
}

if (isset($_SESSION['user_id'])) {
    header("location: user_dashboard.php");
    exit;
}

// Jika tidak ada session, arahkan ke login
header("location: login.php");
exit;
