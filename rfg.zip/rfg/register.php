<?php
// register.php
require 'config.php';

$error = '';
$success = '';

// Proses form saat disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $email = $_POST['email'];
    $password = $_POST['password']; // PENTING: Gunakan password_hash di aplikasi production
    $confirm_password = $_POST['confirm_password'];

    // Validasi password confirmation
    if ($password !== $confirm_password) {
        $error = "Password dan konfirmasi password tidak cocok.";
    } else {
        // Siapkan statement untuk mencegah SQL Injection
        $stmt = $conn->prepare("INSERT INTO pengguna (Nama, Alamat, Nomor_Telepon, Email, Password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama, $alamat, $telepon, $email, $password);

        if ($stmt->execute()) {
            $success = "Registrasi berhasil! Silakan <a href='login.php'>login</a>.";
        } else {
            // Cek error duplikasi
            if ($conn->errno == 1062) {
                $error = "Registrasi gagal. Email atau Nomor Telepon sudah terdaftar.";
            } else {
                $error = "Terjadi kesalahan pada server. Silakan coba lagi.";
            }
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi - RefillGo</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="css/register_styles.css" rel="stylesheet">
</head>

<body>
    <div class="register-container">
        <div class="register-background">
            <div class="background-shapes">
                <div class="shape shape-1"></div>
                <div class="shape shape-2"></div>
                <div class="shape shape-3"></div>
                <div class="shape shape-4"></div>
            </div>
        </div>

        <div class="register-content">
            <div class="register-card">
                <div class="register-header">
                    <div class="logo-section">
                        <img src="img/refillgologo.webp" alt="RefillGo Logo" class="register-logo">
                        <h1>RefillGo</h1>
                        <p>Bergabung dengan Layanan Terpercaya</p>
                    </div>
                </div>

                <div class="register-body">
                    <h2>Buat Akun Baru</h2>
                    <p class="register-subtitle">Lengkapi informasi di bawah untuk membuat akun</p>

                    <?php if ($error): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <span><?php echo $error; ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <span><?php echo $success; ?></span>
                        </div>
                    <?php endif; ?>

                    <form action="register.php" method="post" class="register-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="nama">
                                    <i class="fas fa-user"></i>
                                    Nama Lengkap
                                </label>
                                <input type="text" name="nama" id="nama" required class="form-control" placeholder="Masukkan nama lengkap Anda" value="<?php echo isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label for="telepon">
                                    <i class="fas fa-phone"></i>
                                    Nomor Telepon
                                </label>
                                <input type="tel" name="telepon" id="telepon" required class="form-control" placeholder="Contoh: 08123456789" value="<?php echo isset($_POST['telepon']) ? htmlspecialchars($_POST['telepon']) : ''; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i>
                                Alamat Email
                            </label>
                            <input type="email" name="email" id="email" required class="form-control" placeholder="Masukkan email Anda" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label for="alamat">
                                <i class="fas fa-map-marker-alt"></i>
                                Alamat Lengkap
                            </label>
                            <textarea name="alamat" id="alamat" rows="3" required class="form-control" placeholder="Masukkan alamat lengkap untuk pengiriman"><?php echo isset($_POST['alamat']) ? htmlspecialchars($_POST['alamat']) : ''; ?></textarea>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">
                                    <i class="fas fa-lock"></i>
                                    Password
                                </label>
                                <div class="password-input">
                                    <input type="password" name="password" id="password" required class="form-control" placeholder="Minimal 6 karakter">
                                    <button type="button" class="password-toggle" onclick="togglePassword('password', 'password-icon')">
                                        <i class="fas fa-eye" id="password-icon"></i>
                                    </button>
                                </div>
                                <div class="password-strength">
                                    <div class="strength-bar">
                                        <div class="strength-fill"></div>
                                    </div>
                                    <span class="strength-text">Kekuatan password</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">
                                    <i class="fas fa-lock"></i>
                                    Konfirmasi Password
                                </label>
                                <div class="password-input">
                                    <input type="password" name="confirm_password" id="confirm_password" required class="form-control" placeholder="Ulangi password">
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password', 'confirm-password-icon')">
                                        <i class="fas fa-eye" id="confirm-password-icon"></i>
                                    </button>
                                </div>
                                <div class="password-match">
                                    <span class="match-text"></span>
                                </div>
                            </div>
                        </div>

                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="terms" required>
                                <span class="checkmark"></span>
                                Saya setuju dengan <a href="#" class="terms-link">Syarat & Ketentuan</a> dan <a href="#" class="privacy-link">Kebijakan Privasi</a>
                            </label>
                        </div>

                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="newsletter">
                                <span class="checkmark"></span>
                                Saya ingin menerima informasi promo dan penawaran menarik
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary btn-register">
                            <i class="fas fa-user-plus"></i>
                            Daftar Sekarang
                        </button>
                    </form>
                </div>

                <div class="register-footer">
                    <p>Sudah punya akun? <a href="login.php" class="login-link">Masuk di sini</a></p>
                </div>
            </div>

            <div class="register-info">
                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3>Mudah & Cepat</h3>
                    <p>Proses registrasi yang sederhana dan cepat, hanya butuh beberapa menit untuk bergabung</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-gift"></i>
                    </div>
                    <h3>Promo Menarik</h3>
                    <p>Dapatkan penawaran khusus dan diskon untuk pelanggan baru yang mendaftar hari ini</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>Dukungan 24/7</h3>
                    <p>Tim customer service kami siap membantu Anda kapan saja dengan layanan terbaik</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3>Kualitas Terjamin</h3>
                    <p>Bergabung dengan ribuan pelanggan yang telah mempercayai layanan berkualitas kami</p>
                </div>
            </div>
        </div>
    </div>

    <script src="js/register_script.js"></script>
</body>

</html>