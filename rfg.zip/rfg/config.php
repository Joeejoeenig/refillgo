<?php

/**
 * config.php
 * File untuk konfigurasi dan koneksi database.
 * Juga untuk memulai session.
 */

// Konfigurasi Database
$db_host = 'localhost'; // Biasanya 'localhost'
$db_user = 'root';      // User default XAMPP
$db_pass = '';          // Password default XAMPP kosong
$db_name = 'dbgalon';  // Nama database sesuai file SQL Anda

// Membuat koneksi ke database menggunakan MySQLi
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Memeriksa apakah koneksi berhasil atau gagal
if ($conn->connect_error) {
    // Jika gagal, hentikan script dan tampilkan pesan error
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Memulai session jika belum ada session yang aktif
// Session digunakan untuk menyimpan status login pengguna
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
