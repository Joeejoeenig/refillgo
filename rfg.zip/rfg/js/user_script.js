document.addEventListener("DOMContentLoaded", () => {
  // Sidebar navigation
  const navItems = document.querySelectorAll(".nav-item")
  const contentSections = document.querySelectorAll(".content-section")
  const pageTitle = document.querySelector(".page-title")
  const sidebarToggle = document.querySelector(".sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")

  // Navigation functionality
  navItems.forEach((item) => {
    item.addEventListener("click", function (e) {
      e.preventDefault()

      // Remove active class from all nav items
      navItems.forEach((nav) => nav.classList.remove("active"))

      // Add active class to clicked item
      this.classList.add("active")

      // Show target section
      const targetSection = this.getAttribute("data-section")
      window.showSection(targetSection)
    })
  })

  // Function to show specific section
  window.showSection = (sectionId) => {
    // Hide all content sections
    contentSections.forEach((section) => section.classList.remove("active"))

    // Show target section
    const targetElement = document.getElementById(sectionId)
    if (targetElement) {
      targetElement.classList.add("active")

      // Update page title
      const sectionTitles = {
        dashboard: "Dashboard",
        pesan: "Buat Pesanan",
        riwayat: "Riwayat Pesanan",
        profil: "Profil Saya",
      }
      pageTitle.textContent = sectionTitles[sectionId] || "Dashboard"

      // Update active nav item
      navItems.forEach((nav) => nav.classList.remove("active"))
      const activeNav = document.querySelector(`[data-section="${sectionId}"]`)
      if (activeNav) {
        activeNav.classList.add("active")
      }
    }
  }

  // Sidebar toggle for mobile
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 1024) {
      if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove("active")
      }
    }
  })

  // Order form calculations
  const galonSelect = document.getElementById("galon_id")
  const jumlahInput = document.getElementById("jumlah")
  const totalPriceElement = document.querySelector(".total-price")

  function updateTotalPrice() {
    const selectedOption = galonSelect.options[galonSelect.selectedIndex]
    const price = selectedOption.getAttribute("data-price") || 0
    const quantity = jumlahInput.value || 1
    const total = price * quantity

    if (totalPriceElement) {
      totalPriceElement.textContent = `Rp ${new Intl.NumberFormat("id-ID").format(total)}`
    }
  }

  if (galonSelect && jumlahInput) {
    galonSelect.addEventListener("change", updateTotalPrice)
    jumlahInput.addEventListener("input", updateTotalPrice)
  }

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })

  // BLOK KODE YANG MENYEBABKAN ERROR TELAH DIHAPUS DARI SINI

  // Store original button text
  const submitButtons = document.querySelectorAll('button[type="submit"]')
  submitButtons.forEach((btn) => {
    btn.setAttribute("data-original-text", btn.innerHTML)
  })

  // Smooth scrolling for internal links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Initialize tooltips (basic implementation)
  const tooltipElements = document.querySelectorAll("[title]")
  tooltipElements.forEach((element) => {
    element.addEventListener("mouseenter", function () {
      const tooltip = document.createElement("div")
      tooltip.className = "tooltip"
      tooltip.textContent = this.getAttribute("title")
      document.body.appendChild(tooltip)

      const rect = this.getBoundingClientRect()
      tooltip.style.left = rect.left + rect.width / 2 + "px"
      tooltip.style.top = rect.top - 30 + "px"
    })

    element.addEventListener("mouseleave", () => {
      const tooltip = document.querySelector(".tooltip")
      if (tooltip) {
        tooltip.remove()
      }
    })
  })
})