document.addEventListener("DOMContentLoaded", () => {
  // Sidebar navigation
  const navItems = document.querySelectorAll(".nav-item")
  const contentSections = document.querySelectorAll(".content-section")
  const pageTitle = document.querySelector(".page-title")
  const sidebarToggle = document.querySelector(".sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")

  // Navigation functionality
  navItems.forEach((item) => {
    item.addEventListener("click", function (e) {
      e.preventDefault()

      // Remove active class from all nav items
      navItems.forEach((nav) => nav.classList.remove("active"))

      // Add active class to clicked item
      this.classList.add("active")

      // Hide all content sections
      contentSections.forEach((section) => section.classList.remove("active"))

      // Show target section
      const targetSection = this.getAttribute("data-section")
      const targetElement = document.getElementById(targetSection)
      if (targetElement) {
        targetElement.classList.add("active")

        // Update page title
        const sectionTitle = this.querySelector("span").textContent
        pageTitle.textContent = sectionTitle
      }
    })
  })

  // Sidebar toggle for mobile
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 1024) {
      if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove("active")
      }
    }
  })

  document.querySelectorAll('.status-select').forEach(select => {
    select.addEventListener('change', function (e) {
      // Highlight perubahan dengan menambahkan class
      this.classList.add('status-changed');
      // Aktifkan tombol save
      const saveBtn = this.closest('form').querySelector('button[type="submit"]');
      saveBtn.classList.add('btn-highlight');
    });
  });

  // Initialize tooltips (if you want to add them later)
  function initTooltips() {
    const tooltipElements = document.querySelectorAll("[data-tooltip]")
    tooltipElements.forEach((element) => {
      element.addEventListener("mouseenter", showTooltip)
      element.addEventListener("mouseleave", hideTooltip)
    })
  }

  function showTooltip(e) {
    // Tooltip implementation
  }

  function hideTooltip(e) {
    // Tooltip implementation
  }

  // Search functionality (you can implement this later)
  function initSearch() {
    const searchInputs = document.querySelectorAll(".search-input")
    searchInputs.forEach((input) => {
      input.addEventListener("input", function () {
        const searchTerm = this.value.toLowerCase()
        const table = this.closest(".card").querySelector(".data-table tbody")
        const rows = table.querySelectorAll("tr")

        rows.forEach((row) => {
          const text = row.textContent.toLowerCase()
          row.style.display = text.includes(searchTerm) ? "" : "none"
        })
      })
    })
  }

  // Initialize all features
  initTooltips()
  initSearch()
})