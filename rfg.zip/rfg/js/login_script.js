document.addEventListener("DOMContentLoaded", () => {
  // Password toggle functionality
  window.togglePassword = () => {
    const passwordInput = document.getElementById("password")
    const passwordIcon = document.getElementById("password-icon")

    if (passwordInput.type === "password") {
      passwordInput.type = "text"
      passwordIcon.className = "fas fa-eye-slash"
    } else {
      passwordInput.type = "password"
      passwordIcon.className = "fas fa-eye"
    }
  }

  // Form validation and submission
  const loginForm = document.querySelector(".login-form")
  const submitButton = document.querySelector(".btn-login")

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      // Basic validation
      if (!email || !password) {
        e.preventDefault()
        showAlert("Mohon lengkapi semua field yang diperlukan", "error")
        return
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        e.preventDefault()
        showAlert("Format email tidak valid", "error")
        return
      }

      // Show loading state
      if (submitButton) {
        submitButton.classList.add("btn-loading")
        submitButton.disabled = true

        // Reset button after 5 seconds (in case of server issues)
        setTimeout(() => {
          submitButton.classList.remove("btn-loading")
          submitButton.disabled = false
        }, 5000)
      }
    })
  }

  // User type selection animation
  const userTypeOptions = document.querySelectorAll(".user-type-option")
  userTypeOptions.forEach((option) => {
    option.addEventListener("click", function () {
      // Add ripple effect
      const ripple = document.createElement("div")
      ripple.className = "ripple"
      this.appendChild(ripple)

      setTimeout(() => {
        ripple.remove()
      }, 600)
    })
  })

  // Auto-hide alerts
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      alert.style.transform = "translateY(-10px)"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })

  // Social login handlers (placeholder)
  const socialButtons = document.querySelectorAll(".social-btn")
  socialButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const provider = this.classList.contains("google-btn") ? "Google" : "Facebook"
      showAlert(`Login dengan ${provider} akan segera tersedia`, "info")
    })
  })

  // Forgot password handler (placeholder)
  const forgotPasswordLink = document.querySelector(".forgot-password")
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", (e) => {
      e.preventDefault()
      showAlert("Fitur reset password akan segera tersedia", "info")
    })
  }

  // Remember me functionality
  const rememberCheckbox = document.querySelector('input[name="remember"]')
  const emailInput = document.getElementById("email")

  // Load saved email if remember me was checked
  if (localStorage.getItem("rememberMe") === "true") {
    const savedEmail = localStorage.getItem("savedEmail")
    if (savedEmail && emailInput) {
      emailInput.value = savedEmail
      rememberCheckbox.checked = true
    }
  }

  // Save email when remember me is checked
  if (rememberCheckbox && emailInput) {
    rememberCheckbox.addEventListener("change", function () {
      if (this.checked) {
        localStorage.setItem("rememberMe", "true")
        localStorage.setItem("savedEmail", emailInput.value)
      } else {
        localStorage.removeItem("rememberMe")
        localStorage.removeItem("savedEmail")
      }
    })
  }

  // Keyboard navigation improvements
  document.addEventListener("keydown", (e) => {
    // Enter key on user type options
    if (e.key === "Enter" && e.target.classList.contains("user-type-option")) {
      e.target.click()
    }

    // Escape key to close alerts
    if (e.key === "Escape") {
      const alerts = document.querySelectorAll(".alert")
      alerts.forEach((alert) => alert.remove())
    }
  })

  // Form field animations
  const formControls = document.querySelectorAll(".form-control")
  formControls.forEach((input) => {
    input.addEventListener("focus", function () {
      this.parentElement.classList.add("focused")
    })

    input.addEventListener("blur", function () {
      this.parentElement.classList.remove("focused")
      if (this.value) {
        this.parentElement.classList.add("filled")
      } else {
        this.parentElement.classList.remove("filled")
      }
    })

    // Check if field is pre-filled
    if (input.value) {
      input.parentElement.classList.add("filled")
    }
  })

  // Utility function to show alerts
  function showAlert(message, type = "info") {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll(".alert")
    existingAlerts.forEach((alert) => alert.remove())

    const alert = document.createElement("div")
    alert.className = `alert alert-${type}`

    const icon =
      type === "error" ? "fas fa-exclamation-circle" : type === "success" ? "fas fa-check-circle" : "fas fa-info-circle"

    alert.innerHTML = `
      <i class="${icon}"></i>
      <span>${message}</span>
    `

    const loginBody = document.querySelector(".login-body")
    const firstElement = loginBody.querySelector("h2")
    loginBody.insertBefore(alert, firstElement.nextSibling)

    // Auto-hide after 5 seconds
    setTimeout(() => {
      alert.style.opacity = "0"
      alert.style.transform = "translateY(-10px)"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  }

  // Add ripple effect CSS dynamically
  const style = document.createElement("style")
  style.textContent = `
    .ripple {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.3);
      transform: scale(0);
      animation: ripple-animation 0.6s linear;
      pointer-events: none;
    }
    
    @keyframes ripple-animation {
      to {
        transform: scale(4);
        opacity: 0;
      }
    }
    
    .user-type-option {
      position: relative;
      overflow: hidden;
    }
  `
  document.head.appendChild(style)
})
