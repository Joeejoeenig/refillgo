document.addEventListener("DOMContentLoaded", () => {
  // Password toggle functionality
  window.togglePassword = (inputId, iconId) => {
    const passwordInput = document.getElementById(inputId)
    const passwordIcon = document.getElementById(iconId)

    if (passwordInput.type === "password") {
      passwordInput.type = "text"
      passwordIcon.className = "fas fa-eye-slash"
    } else {
      passwordInput.type = "password"
      passwordIcon.className = "fas fa-eye"
    }
  }

  // Form validation and submission
  const registerForm = document.querySelector(".register-form")
  const submitButton = document.querySelector(".btn-register")

  // Password strength checker
  const passwordInput = document.getElementById("password")
  const confirmPasswordInput = document.getElementById("confirm_password")
  const strengthBar = document.querySelector(".strength-fill")
  const strengthText = document.querySelector(".strength-text")
  const matchText = document.querySelector(".match-text")

  if (passwordInput && strengthBar) {
    passwordInput.addEventListener("input", function () {
      const password = this.value
      const strength = checkPasswordStrength(password)

      // Update strength bar
      strengthBar.className = `strength-fill ${strength.class}`
      strengthText.textContent = strength.text
    })
  }

  if (confirmPasswordInput && matchText) {
    confirmPasswordInput.addEventListener("input", function () {
      const password = passwordInput.value
      const confirmPassword = this.value

      if (confirmPassword === "") {
        matchText.textContent = ""
        matchText.className = "match-text"
      } else if (password === confirmPassword) {
        matchText.textContent = "✓ Password cocok"
        matchText.className = "match-text match"
      } else {
        matchText.textContent = "✗ Password tidak cocok"
        matchText.className = "match-text no-match"
      }
    })
  }

  // Phone number formatting
  const phoneInput = document.getElementById("telepon")
  if (phoneInput) {
    phoneInput.addEventListener("input", function () {
      let value = this.value.replace(/\D/g, "")

      // Format Indonesian phone number
      if (value.startsWith("62")) {
        value = "+" + value
      } else if (value.startsWith("08")) {
        // Keep as is
      } else if (value.startsWith("8")) {
        value = "0" + value
      }

      this.value = value
    })
  }

  // Email validation
  const emailInput = document.getElementById("email")
  if (emailInput) {
    emailInput.addEventListener("blur", function () {
      const email = this.value
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

      if (email && !emailRegex.test(email)) {
        this.classList.add("invalid")
        showFieldError(this, "Format email tidak valid")
      } else {
        this.classList.remove("invalid")
        this.classList.add("valid")
        hideFieldError(this)
      }
    })
  }

  // Form submission
  if (registerForm) {
    registerForm.addEventListener("submit", (e) => {
      const formData = new FormData(registerForm)
      const data = Object.fromEntries(formData)

      // Validate required fields
      const requiredFields = ["nama", "alamat", "telepon", "email", "password", "confirm_password"]
      let hasErrors = false

      requiredFields.forEach((field) => {
        const input = document.getElementById(field)
        if (!data[field] || data[field].trim() === "") {
          showFieldError(input, "Field ini wajib diisi")
          hasErrors = true
        }
      })

      // Validate password match
      if (data.password !== data.confirm_password) {
        showFieldError(confirmPasswordInput, "Password tidak cocok")
        hasErrors = true
      }

      // Validate password strength
      const strength = checkPasswordStrength(data.password)
      if (strength.score < 2) {
        showFieldError(passwordInput, "Password terlalu lemah")
        hasErrors = true
      }

      // Validate terms acceptance
      if (!data.terms) {
        showAlert("Anda harus menyetujui Syarat & Ketentuan", "error")
        hasErrors = true
      }

      if (hasErrors) {
        e.preventDefault()
        return
      }

      // Show loading state
      if (submitButton) {
        submitButton.classList.add("btn-loading")
        submitButton.disabled = true

        // Reset button after 5 seconds (in case of server issues)
        setTimeout(() => {
          submitButton.classList.remove("btn-loading")
          submitButton.disabled = false
        }, 5000)
      }
    })
  }

  // Social register handlers (placeholder)
  const socialButtons = document.querySelectorAll(".social-btn")
  socialButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const provider = this.classList.contains("google-btn") ? "Google" : "Facebook"
      showAlert(`Registrasi dengan ${provider} akan segera tersedia`, "info")
    })
  })

  // Terms and privacy links (placeholder)
  const termsLink = document.querySelector(".terms-link")
  const privacyLink = document.querySelector(".privacy-link")

  if (termsLink) {
    termsLink.addEventListener("click", (e) => {
      e.preventDefault()
      showAlert("Halaman Syarat & Ketentuan akan segera tersedia", "info")
    })
  }

  if (privacyLink) {
    privacyLink.addEventListener("click", (e) => {
      e.preventDefault()
      showAlert("Halaman Kebijakan Privasi akan segera tersedia", "info")
    })
  }

  // Auto-hide alerts
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      alert.style.transform = "translateY(-10px)"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 8000) // Longer timeout for registration success
  })

  // Form field animations
  const formControls = document.querySelectorAll(".form-control")
  formControls.forEach((input) => {
    input.addEventListener("focus", function () {
      this.parentElement.classList.add("focused")
    })

    input.addEventListener("blur", function () {
      this.parentElement.classList.remove("focused")
      if (this.value) {
        this.parentElement.classList.add("filled")
      } else {
        this.parentElement.classList.remove("filled")
      }
    })

    // Check if field is pre-filled
    if (input.value) {
      input.parentElement.classList.add("filled")
    }
  })

  // Utility functions
  function checkPasswordStrength(password) {
    let score = 0
    const feedback = []

    if (password.length >= 8) score++
    if (password.match(/[a-z]/)) score++
    if (password.match(/[A-Z]/)) score++
    if (password.match(/[0-9]/)) score++
    if (password.match(/[^a-zA-Z0-9]/)) score++

    const strengths = [
      { class: "weak", text: "Sangat lemah", score: 0 },
      { class: "weak", text: "Lemah", score: 1 },
      { class: "fair", text: "Cukup", score: 2 },
      { class: "good", text: "Baik", score: 3 },
      { class: "strong", text: "Sangat kuat", score: 4 },
    ]

    const strength = strengths.find((s) => s.score === Math.min(score, 4)) || strengths[0]
    return { ...strength, score }
  }

  function showFieldError(field, message) {
    hideFieldError(field)

    const errorDiv = document.createElement("div")
    errorDiv.className = "field-error"
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`

    field.parentElement.appendChild(errorDiv)
    field.classList.add("invalid")
  }

  function hideFieldError(field) {
    const existingError = field.parentElement.querySelector(".field-error")
    if (existingError) {
      existingError.remove()
    }
    field.classList.remove("invalid")
  }

  function showAlert(message, type = "info") {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll(".alert")
    existingAlerts.forEach((alert) => alert.remove())

    const alert = document.createElement("div")
    alert.className = `alert alert-${type}`

    const icon =
      type === "error" ? "fas fa-exclamation-circle" : type === "success" ? "fas fa-check-circle" : "fas fa-info-circle"

    alert.innerHTML = `
      <i class="${icon}"></i>
      <span>${message}</span>
    `

    const registerBody = document.querySelector(".register-body")
    const firstElement = registerBody.querySelector("h2")
    registerBody.insertBefore(alert, firstElement.nextSibling)

    // Auto-hide after 5 seconds
    setTimeout(() => {
      alert.style.opacity = "0"
      alert.style.transform = "translateY(-10px)"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  }

  // Add field error styles dynamically
  const style = document.createElement("style")
  style.textContent = `
    .field-error {
      color: #dc2626;
      font-size: 0.75rem;
      margin-top: 0.25rem;
      display: flex;
      align-items: center;
      gap: 0.25rem;
    }
    
    .form-control.invalid {
      border-color: #dc2626 !important;
    }
    
    .form-control.valid {
      border-color: #059669 !important;
    }
  `
  document.head.appendChild(style)
})
