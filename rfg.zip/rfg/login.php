<?php
// login.php
require 'config.php';

$error = '';

// Jika sudah login, redirect ke dashboard masing-masing
if (isset($_SESSION['admin_id'])) {
    header("location: admin_dashboard.php");
    exit;
}

if (isset($_SESSION['user_id'])) {
    header("location: user_dashboard.php");
    exit;
}

// Proses form saat disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user_type = $_POST['user_type'];

    if ($user_type == 'admin') {
        // Login sebagai Admin
        $stmt = $conn->prepare("SELECT AdminID, NamaAdmin, Password FROM admin WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $admin = $result->fetch_assoc();
            // PENTING: Gunakan password_verify di aplikasi production
            if ($password == $admin['Password']) {
                $_SESSION['admin_id'] = $admin['AdminID'];
                $_SESSION['admin_name'] = $admin['NamaAdmin'];
                header("location: admin_dashboard.php");
                exit;
            } else {
                $error = "Password admin salah.";
            }
        } else {
            $error = "Email admin tidak ditemukan.";
        }
    } else {
        // Login sebagai Pengguna
        $stmt = $conn->prepare("SELECT UserID, Nama, Password FROM pengguna WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            // PENTING: Gunakan password_verify di aplikasi production
            if ($password == $user['Password']) {
                $_SESSION['user_id'] = $user['UserID'];
                $_SESSION['user_name'] = $user['Nama'];
                header("location: user_dashboard.php");
                exit;
            } else {
                $error = "Password pengguna salah.";
            }
        } else {
            $error = "Email pengguna tidak ditemukan.";
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RefillGo</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="css/login_styles.css" rel="stylesheet">
</head>

<body>
    <div class="login-container">
        <div class="login-background">
            <div class="background-shapes">
                <div class="shape shape-1"></div>
                <div class="shape shape-2"></div>
                <div class="shape shape-3"></div>
            </div>
        </div>

        <div class="login-content">
            <div class="login-card">
                <div class="login-header">
                    <div class="logo-section">
                        <img src="img/refillgologo.webp" alt="RefillGo Logo" class="login-logo">
                        <h1>RefillGo</h1>
                        <p>Sistem Manajemen Air Galon</p>
                    </div>
                </div>

                <div class="login-body">
                    <h2>Masuk ke Akun Anda</h2>
                    <p class="login-subtitle">Silakan masukkan kredensial Anda untuk melanjutkan</p>

                    <?php if ($error): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <span><?php echo $error; ?></span>
                        </div>
                    <?php endif; ?>

                    <form action="login.php" method="post" class="login-form">
                        <div class="form-group">
                            <label for="user_type">
                                <i class="fas fa-user-tag"></i>
                                Login Sebagai
                            </label>
                            <div class="user-type-selector">
                                <input type="radio" id="pengguna" name="user_type" value="pengguna" checked>
                                <label for="pengguna" class="user-type-option">
                                    <i class="fas fa-user"></i>
                                    <span>Pelanggan</span>
                                </label>

                                <input type="radio" id="admin" name="user_type" value="admin">
                                <label for="admin" class="user-type-option">
                                    <i class="fas fa-user-shield"></i>
                                    <span>Administrator</span>
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i>
                                Alamat Email
                            </label>
                            <input type="email" name="email" id="email" required class="form-control" placeholder="Masukkan email Anda">
                        </div>

                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i>
                                Password
                            </label>
                            <div class="password-input">
                                <input type="password" name="password" id="password" required class="form-control" placeholder="Masukkan password Anda">
                                <button type="button" class="password-toggle" onclick="togglePassword()">
                                    <i class="fas fa-eye" id="password-icon"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="remember">
                                <span class="checkmark"></span>
                                Ingat saya
                            </label>
                            <a href="#" class="forgot-password">Lupa password?</a>
                        </div>

                        <button type="submit" class="btn btn-primary btn-login">
                            <i class="fas fa-sign-in-alt"></i>
                            Masuk
                        </button>
                    </form>
                </div>

                <div class="login-footer">
                    <p>Belum punya akun? <a href="register.php" class="register-link">Daftar di sini</a></p>
                </div>
            </div>

            <div class="login-info">
                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-tint"></i>
                    </div>
                    <h3>Layanan Air Galon Terpercaya</h3>
                    <p>Nikmati kemudahan pesan air galon dengan sistem yang modern dan terpercaya</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <h3>Pengiriman Cepat</h3>
                    <p>Pengiriman langsung ke lokasi Anda dengan layanan yang cepat dan profesional</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Kualitas Terjamin</h3>
                    <p>Air berkualitas tinggi dengan standar kesehatan yang ketat untuk keluarga Anda</p>
                </div>
            </div>
        </div>
    </div>

    <script src="js/login_script.js"></script>
</body>

</html>